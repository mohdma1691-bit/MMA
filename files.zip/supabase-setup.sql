-- ============================================================
-- إعداد قاعدة بيانات نظام حجز "مجلس الدعيلج" على Supabase
-- نفّذه كاملًا من:  Supabase → SQL Editor → New query → Run
-- مهم: غيّر البريد في الأسطر المعلّمة ↓ ليطابق ADMIN_EMAIL في index.html
-- ============================================================

-- 1) الجداول
create table if not exists public.days (
  date       text primary key,
  status     text not null check (status in ('pending','confirmed')),
  created_at timestamptz not null default now()
);

create table if not exists public.details (
  date       text primary key references public.days(date) on delete cascade,
  name       text not null,
  phone      text not null,
  count      text,
  note       text,
  created_at timestamptz not null default now()
);

-- 2) تفعيل حماية الصفوف (Row Level Security)
alter table public.days    enable row level security;
alter table public.details enable row level security;

-- 3) السياسات
-- days: الحالة يقرؤها الجميع
drop policy if exists days_select on public.days;
create policy days_select on public.days
  for select using ( true );

-- days: أي زائر ينشئ طلبًا (pending) فقط؛ المفتاح الأساسي يمنع تكرار يوم محجوز
drop policy if exists days_insert on public.days;
create policy days_insert on public.days
  for insert with check ( status = 'pending' );

-- days: الاعتماد/التعديل/الحذف للمسؤول فقط (يُحدَّد بالبريد)
drop policy if exists days_update on public.days;
create policy days_update on public.days
  for update using ( (auth.jwt() ->> 'email') = 'admin@majlis.app' );   -- ← غيّر البريد
drop policy if exists days_delete on public.days;
create policy days_delete on public.days
  for delete using ( (auth.jwt() ->> 'email') = 'admin@majlis.app' );   -- ← غيّر البريد

-- details: لا يقرؤها إلا المسؤول
drop policy if exists details_select on public.details;
create policy details_select on public.details
  for select using ( (auth.jwt() ->> 'email') = 'admin@majlis.app' );   -- ← غيّر البريد

-- details: أي زائر ينشئ تفاصيل طلبه (مع تحقّق بسيط)
drop policy if exists details_insert on public.details;
create policy details_insert on public.details
  for insert with check (
    length(name)  > 0 and length(name)  < 80 and
    length(phone) > 0 and length(phone) < 30
  );

-- details: الحذف للمسؤول
drop policy if exists details_delete on public.details;
create policy details_delete on public.details
  for delete using ( (auth.jwt() ->> 'email') = 'admin@majlis.app' );   -- ← غيّر البريد

-- 4) تفعيل المزامنة اللحظية (إن ظهر خطأ "already member" فتجاهله)
alter publication supabase_realtime add table public.days;
alter publication supabase_realtime add table public.details;
